import firebase_admin
import simplejson as json
from firebase_admin import credentials,firestore
cred=credentials.Certificate('./sihtestadminx-firebase-adminsdk-tdfza-4b747d23df.json')
default_app=firebase_admin.initialize_app(cred)
db=firestore.client()
users_ref = db.collection(u'schemes').document(u'testscheme')
try:
    users= users_ref.get()
    
    print(u'Document data: {}'.format(users.to_dict()))
    
except google.cloud.exceptions.NotFound:
    print(u'No such document!')
var=users.to_dict()
z=list(var.keys())
list=[]
for i in range(0,len(z)):
    y=z[i]
    list.append(z[i])
    print(list)
    #x=var[str(y)]
    #print(x)
#'Schemename'
