import simplejson as json
a='somedata'
b='moredata'
postdata={
  		"$class": "org.example.trading.Trade",
  		"commodity": "resource:org.example.trading.Commodity#"+a,
  		"newOwner": "resource:org.example.trading.Trader#"+b
			}
data=str(postdata)
print(data,type(data))
