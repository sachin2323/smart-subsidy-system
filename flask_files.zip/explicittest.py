import simplejson as json
import requests
a=10
b=20
postdata={
  		"$class": "org.example.trading.Trade",
  		"commodity": "resource:org.example.trading.Commodity#"+str(a),
  		"newOwner": "resource:org.example.trading.Trader#"+str(b)
			}
json_string=json.dumps(postdata)
print(json_string)
r=requests.post('http://localhost:3000/api/Trade',json_string)

print(r.text)