from flask import *
import firebase_admin
import simplejson as json
import os
from firebase_admin import credentials,firestore
import requests
cred=credentials.Certificate('./sihtestadminx-firebase-adminsdk-tdfza-4b747d23df.json')
default_app=firebase_admin.initialize_app(cred)
db=firestore.client()
app=Flask(__name__)
a,b='a','b'


@app.route('/',methods=['GET','POST'])
def schemes():
	if request.method=='POST':
		a=request.form['schemename']
		b=request.form['schemedesc']
		#data={'Schemename':a,'schemedesc':b}
		#scheme_ref = db.collection(u'schemes').document(u'testscheme')
		#scheme_ref.set({a:data},merge=True)
		postdata={
  		"$class": "org.example.trading.Trade",
  		"commodity": "resource:org.example.trading.Commodity#"+str(a),
  		"newOwner": "resource:org.example.trading.Trader#"+str(b)
			}
		json_string=str(postdata)
		r=requests.post('http://localhost:3000/api/Trade',json_string)
		print(postdata)
		
		print(json_string)
		
		
	return render_template('scheme.html')

@app.route('/cust',methods=['GET','POST'])
def cust():
    
    
    users_ref = db.collection(u'schemes').document(u'testscheme')
    try:
        users= users_ref.get()
    
        #print(u'Document data: {}'.format(users.to_dict()))
    
    except google.cloud.exceptions.NotFound:
	    print(u'No such document!')
    var=users.to_dict()
    z=list(var.keys())
    

    listx=[]
    for i in range(0,len(z)):
        y=z[i]
        listx.append(z[i])
    
    x=var[str(y)]['Schemename']
    return render_template('cust.html',listx=listx)
@app.route('/json')
def json():
    return render_template('json.html')

#background process happening without any refreshing
@app.route('/background_process_test')
def background_process_test():
	cmd='''   cd ~/fabric-dev-servers
    export FABRIC_VERSION=hlfv12
    ./startFabric.sh'''
	os.system(cmd)
	return "nothing"
@app.route('/background_process_test1')
def background_process_test1():
	cmd='./createPeerAdminCard.sh'
	os.system(cmd)
	return "nothing"

@app.route('/background_process_test2')
def background_process_test2():
	cmd='composer network install --card PeerAdmin@hlfv1 --archiveFile trade-network.bna'
	os.system(cmd)
	return "nothing"

@app.route('/background_process_test3')
def background_process_test3():
	cmd='composer network start --networkName trade-network --networkVersion 0.2.6 --networkAdmin admin --networkAdminEnrollSecret adminpw --card PeerAdmin@hlfv1 --file networkadmin.card'
	os.system(cmd)
	return "nothing"

@app.route('/background_process_test4')
def background_process_test4():
	cmd='composer card import --file networkadmin.card'
	os.system(cmd)
	return "nothing"

@app.route('/background_process_test5')
def background_process_test5():
	cmd='composer network ping --card admin@trade-network'
	os.system(cmd)
	return "nothing"

@app.route('/background_process_test6')
def background_process_test6():
	cmd='composer-rest-server'
	os.system(cmd)
	return "nothing"

if __name__=='__main__':
	app.run(host='127.0.0.1', port=4000,debug=True)
