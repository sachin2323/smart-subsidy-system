from flask import *
import firebase_admin
import simplejson as json
import os
from firebase_admin import credentials,firestore
import requests
@app.route('/',methods=['GET','POST'])
def schemes():
	if request.method=='POST':
		a=request.form['schemename']
		b=request.form['schemedesc']
		#data={'Schemename':a,'schemedesc':b}
		#scheme_ref = db.collection(u'schemes').document(u'testscheme')
		#scheme_ref.set({a:data},merge=True)
		postdata={
  		"$class": "org.example.trading.Trade",
  		"commodity": "resource:org.example.trading.Commodity#"+str(a),
  		"newOwner": "resource:org.example.trading.Trader#"+str(b)
			}
		r=requests.post('http://localhost:3000/api/Trade',json=postdata)
		print(r.text)
		
		
	return render_template('scheme.html')
if __name__=='__main__':
	app.run(host='127.0.0.1', port=4000,debug=True)
